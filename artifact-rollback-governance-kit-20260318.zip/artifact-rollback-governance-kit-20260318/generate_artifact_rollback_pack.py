from __future__ import annotations

from pathlib import Path
from typing import Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from pptx import Presentation
from pptx.dml.color import RGBColor as PPTColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Cm as PPTCm
from pptx.util import Pt as PPTPt


BASE_DIR = Path(r"C:\Users\ljm\artifact-rollback-governance-kit-20260318")
DOCX_PATH = BASE_DIR / "artifact_rollback_governance_document.docx"
PPTX_PATH = BASE_DIR / "artifact_rollback_governance_presentation.pptx"
MD_PATH = BASE_DIR / "artifact_rollback_governance_document.md"
NOTE_PATH = BASE_DIR / "delivery_note.txt"


TITLE = "制品部署后回退治理方案"
SUBTITLE = "适用于镜像、DDL、DML 等制品的回退设计与治理方案"
AUTHOR = "Codex"
DATE_TEXT = "2026-03-18"


CORE_CONCLUSION = [
    "回退不应设计成一个统一动作，而应设计成一套分类型恢复机制。",
    "镜像类以版本回退为主，DDL 以向前兼容和前滚修复为主，DML 以补偿和备份恢复为主。",
    "从治理角度，最优路线是“元数据驱动 + 分类型策略 + 自动校验验收 + 审计闭环”。",
    "短期可先用文件化元数据 manifest 起步，中期再沉淀为中心化元数据和统一编排能力。",
]


WITHOUT_METADATA_POINTS = [
    "以脚本约定、发布单、人工经验和部署平台历史记录支撑回退。",
    "镜像依赖 tag 或历史 revision，DDL 依赖 up/down.sql，DML 依赖人工补偿脚本。",
    "优点是上手快、改造小、适合低复杂度场景。",
    "缺点是回退能力不稳定，强依赖人，无法统一编排，难以自动审计和风险拦截。",
]


WITH_METADATA_POINTS = [
    "以制品元数据显式描述制品类型、版本、依赖、回退策略、校验项、审批和备份要求。",
    "系统可基于元数据决定某个制品是否可回退、如何回退、何时禁止自动回退。",
    "优点是可治理、可审计、可编排、可做统一前后检查。",
    "代价是需要建设元数据模型、执行引擎以及研发/DBA/运维的产物规范。",
]


COMPARISON_ROWS = [
    ("建设成本", "低，依赖现有流程和脚本", "中高，需要建模和平台能力"),
    ("落地速度", "快", "中等"),
    ("自动化程度", "低", "高"),
    ("跨制品统一编排", "弱", "强"),
    ("审批与审计", "碎片化", "可标准化"),
    ("高风险变更治理", "主要靠人", "可通过规则系统拦截"),
    ("长期可扩展性", "差", "好"),
]


METADATA_FIELDS = [
    ("releaseId", "发布单唯一标识", "rel-20260318-001"),
    ("system", "系统或应用名", "order-center"),
    ("env", "目标环境", "prod"),
    ("artifactType", "制品类型", "image / ddl / dml / config"),
    ("version", "版本号", "2.4.1 / V20260318_01"),
    ("sourceRef", "来源引用", "镜像 digest、git commit、SQL 路径"),
    ("deployOrder", "部署顺序", "10 / 20 / 30"),
    ("dependsOn", "依赖制品", "order-api depends on schema"),
    ("reversible", "是否天然可逆", "true / false"),
    ("rollbackPolicy", "回退策略", "DIRECT_ROLLBACK 等"),
    ("rollbackTarget", "回退目标", "previous_stable"),
    ("preChecks", "执行前校验", "image_exists, backup_exists"),
    ("postChecks", "执行后验证", "health_check, sample_verify"),
    ("approvalPolicy", "审批策略", "AUTO / MANUAL"),
    ("backupRequirement", "备份要求", "NONE / SNAPSHOT_REQUIRED"),
    ("compatibility", "兼容性要求", "minSchemaVersion 等"),
    ("riskLevel", "风险等级", "low / medium / high"),
    ("owner", "责任团队", "app-team / dba-team / data-team"),
]


ROLLBACK_POLICIES = [
    ("DIRECT_ROLLBACK", "直接回退到指定或上一稳定版本"),
    ("COMPENSATE", "通过补偿动作恢复"),
    ("FORWARD_FIX_ONLY", "不允许反向回退，仅允许前滚修复"),
    ("RESTORE_FROM_BACKUP", "依赖备份点或快照恢复"),
    ("MANUAL_ONLY", "系统不自动处理，只允许人工处理"),
]


STATE_MACHINE_LINES = [
    "发布单主状态：CREATED -> APPROVED -> PRECHECKING -> READY -> DEPLOYING -> VERIFYING -> STABLE",
    "失败分支：VERIFY_FAILED -> ROLLBACK_PENDING -> ROLLING_BACK -> ROLLBACK_VERIFYING -> ROLLED_BACK / ROLLBACK_FAILED",
    "制品状态：PENDING -> PRECHECKING -> READY -> EXECUTING -> EXECUTED -> VERIFYING -> SUCCEEDED",
    "治理规则：仅 DIRECT_ROLLBACK 进入自动回退队列；任何回退失败一律进入 MANUAL_RECOVERY。",
]


IMAGE_STRATEGY = [
    "镜像必须以不可变版本标识为准，优先记录 digest，而不是仅使用 tag。",
    "部署时记录 current、candidate、previous_stable 三个版本指针。",
    "回退前做 schema 兼容性校验，避免应用回退到与现有表结构不兼容的版本。",
    "回退动作本质是将 workload 指回上一稳定版本，并在完成后自动做健康检查、核心接口探测和容量观察。",
]


DDL_STRATEGY = [
    "DDL 不应默认追求 down.sql 式回退，核心是降低必须回退的概率。",
    "强制采用 expand -> migrate -> contract 的兼容性迁移模式。",
    "expand 类 DDL 可随主流程推进；contract 类 DDL 延后执行，并与应用稳定窗口解耦。",
    "高风险 DDL 默认不进入自动回退，而是执行前滚修复、快照恢复或人工恢复。",
]


DML_STRATEGY = [
    "DML 回退原则上走补偿，而不是反向 SQL。",
    "执行前应声明影响范围、where 条件摘要、分批策略、可暂停能力和补偿方案。",
    "批量 DML 必须具备 checkpoint 机制，并在高风险场景下要求快照或备份点。",
    "删除类、覆盖类和业务含义强的数据修复类 DML，默认仅允许补偿或备份恢复。",
]


GOVERNANCE_RULES = [
    "所有制品随包携带 release-manifest.yaml，作为短期文件化元数据的落地形态。",
    "回退前必须经过 pre-check：目标版本可用、依赖满足、无未完成变更、审批已完成、备份存在。",
    "回退后必须经过 post-check：应用健康、关键 SQL 校验、关键链路探测、样本一致性抽检。",
    "全链路必须落审计：谁在何时对哪个环境执行了什么回退，结果如何，影响了哪些对象。",
    "定期演练：至少对镜像一键回退、DDL 前滚修复、DML 补偿恢复做场景化演练。",
]


ROADMAP_PHASES = [
    (
        "第一阶段：先把镜像回退做扎实",
        [
            "统一镜像不可变版本规则。",
            "部署记录保留 previous_stable。",
            "支持一键回退和自动健康检查。",
        ],
    ),
    (
        "第二阶段：将 DDL 纳入兼容性治理",
        [
            "DDL 分为 expand / migrate / contract 三类。",
            "高风险 DDL 强制人工审批。",
            "contract 类变更从主发布流程中延迟执行。",
        ],
    ),
    (
        "第三阶段：把 DML 纳入补偿体系",
        [
            "要求补偿脚本和 checkpoint 机制。",
            "批量 DML 强制快照或备份点。",
            "建立分批、暂停、续跑能力。",
        ],
    ),
    (
        "第四阶段：平台化收口",
        [
            "汇总 manifest 到中心元数据仓库。",
            "统一状态机、编排、审批、审计和告警。",
            "形成“自动回退 / 人工介入 / 禁止回退”三类策略分流。",
        ],
    ),
]


RISKS = [
    ("只做镜像回退，不做 schema 兼容", "应用可能回退成功但功能仍然不可用。"),
    ("DDL 追求通用自动 down.sql", "极易在复杂数据状态下制造二次事故。"),
    ("DML 不声明补偿策略", "出现问题时只能停留在人工修数和低效排障。"),
    ("没有统一元数据", "难以规模化治理不同制品和不同系统。"),
]


MVP_ACTIONS = [
    "确定 release-manifest.yaml 规范和回退策略枚举。",
    "把发布/回退状态机固化进流水线和部署平台。",
    "先对镜像实现 DIRECT_ROLLBACK。",
    "为 DDL 加入分类和审批门禁，为 DML 加入补偿和备份门禁。",
]


MANIFEST_EXAMPLE = """releaseId: rel-20260318-001
system: order-center
env: prod
riskLevel: high
rollbackWindow: 30m
overallRollbackPolicy: PARTIAL_AUTO

artifacts:
  - artifactId: order-api
    artifactType: image
    version: 2.4.1
    sourceRef: registry.xxx/order-api@sha256:abc123
    deployOrder: 10
    reversible: true
    rollbackPolicy: DIRECT_ROLLBACK
    rollbackTarget: previous_stable
    compatibility:
      minSchemaVersion: 2026.03.0
      maxSchemaVersion: 2026.03.x

  - artifactId: order-schema-20260318
    artifactType: ddl
    version: V20260318_01
    sourceRef: sql/V20260318_01.sql
    deployOrder: 20
    reversible: false
    rollbackPolicy: FORWARD_FIX_ONLY
    compatibility:
      mode: expand

  - artifactId: order-backfill-20260318
    artifactType: dml
    version: BF20260318_01
    sourceRef: sql/BF20260318_01.sql
    deployOrder: 30
    reversible: false
    rollbackPolicy: COMPENSATE
"""


MARKDOWN_TEXT = f"""# {TITLE}

## 1. 文档说明

- 主题：部署后制品回退能力的建设与治理
- 范围：镜像类、DDL、DML，兼顾配置类制品
- 目标读者：平台研发、运维、DBA、应用研发负责人
- 日期：{DATE_TEXT}

## 2. 核心结论

""" + "\n".join(f"- {item}" for item in CORE_CONCLUSION) + """

## 3. 不使用元数据与使用元数据的两种建设路径

### 3.1 不使用元数据

""" + "\n".join(f"- {item}" for item in WITHOUT_METADATA_POINTS) + """

### 3.2 使用元数据

""" + "\n".join(f"- {item}" for item in WITH_METADATA_POINTS) + """

### 3.3 对比结论

| 维度 | 不使用元数据 | 使用元数据 |
| --- | --- | --- |
""" + "\n".join(f"| {a} | {b} | {c} |" for a, b, c in COMPARISON_ROWS) + """

## 4. 最优方案

建议方案：**元数据驱动 + 分类型回退策略 + 自动校验与验收 + 审计闭环**。

短期采用文件化元数据 manifest，作为工程落地起点；中期将元数据沉淀到中心仓库；长期形成统一回退引擎。

## 5. 元数据模型

| 字段 | 说明 | 示例 |
| --- | --- | --- |
""" + "\n".join(f"| {a} | {b} | {c} |" for a, b, c in METADATA_FIELDS) + """

### 5.1 回退策略枚举

| 策略 | 含义 |
| --- | --- |
""" + "\n".join(f"| {a} | {b} |" for a, b in ROLLBACK_POLICIES) + """

### 5.2 manifest 示例

```yaml
""" + MANIFEST_EXAMPLE + """
```

## 6. 发布与回退状态机

""" + "\n".join(f"- {item}" for item in STATE_MACHINE_LINES) + """

## 7. 分类型回退策略

### 7.1 镜像类

""" + "\n".join(f"- {item}" for item in IMAGE_STRATEGY) + """

### 7.2 DDL 类

""" + "\n".join(f"- {item}" for item in DDL_STRATEGY) + """

### 7.3 DML 类

""" + "\n".join(f"- {item}" for item in DML_STRATEGY) + """

## 8. 治理要求

""" + "\n".join(f"- {item}" for item in GOVERNANCE_RULES) + """

## 9. 风险与控制点

| 典型风险 | 控制建议 |
| --- | --- |
""" + "\n".join(f"| {a} | {b} |" for a, b in RISKS) + """

## 10. 落地路线图

""" + "\n".join(
    f"### {phase}\n\n" + "\n".join(f"- {bullet}" for bullet in bullets)
    for phase, bullets in ROADMAP_PHASES
) + """

## 11. MVP 建议

""" + "\n".join(f"- {item}" for item in MVP_ACTIONS) + """

## 12. 结论

最佳路线不是追求“所有制品都能自动反向回退”，而是建立“知道哪些能回、哪些不能回、如何回、回完如何验证”的治理体系。对于你负责的部署与治理工作，优先级应放在元数据规范、状态机、镜像回退能力和数据库变更治理规范上。
"""


def set_doc_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def set_doc_margins(section) -> None:
    section.top_margin = Cm(2.2)
    section.bottom_margin = Cm(2.2)
    section.left_margin = Cm(2.2)
    section.right_margin = Cm(2.2)


def add_table(document: Document, headers: Iterable[str], rows: Iterable[Iterable[str]]) -> None:
    table = document.add_table(rows=1, cols=len(list(headers)))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    hdr_cells = table.rows[0].cells
    header_values = list(headers)
    for idx, text in enumerate(header_values):
        hdr_cells[idx].text = text
        set_doc_cell_shading(hdr_cells[idx], "DCE6F1")
        for paragraph in hdr_cells[idx].paragraphs:
            for run in paragraph.runs:
                run.bold = True
                run.font.name = "Microsoft YaHei"
                run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    for row in rows:
        cells = table.add_row().cells
        for idx, text in enumerate(row):
            cells[idx].text = text
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                paragraph.paragraph_format.space_after = Pt(0)
                for run in paragraph.runs:
                    run.font.name = "Microsoft YaHei"
                    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
                    run.font.size = Pt(10.5)
    document.add_paragraph()


def add_bullet_list(document: Document, items: list[str], level: int = 0) -> None:
    for item in items:
        paragraph = document.add_paragraph(style="List Bullet")
        paragraph.paragraph_format.left_indent = Cm(0.6 + level * 0.5)
        run = paragraph.add_run(item)
        run.font.name = "Microsoft YaHei"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        run.font.size = Pt(11)


def add_numbered_list(document: Document, items: list[str]) -> None:
    for item in items:
        paragraph = document.add_paragraph(style="List Number")
        run = paragraph.add_run(item)
        run.font.name = "Microsoft YaHei"
        run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        run.font.size = Pt(11)


def format_document_styles(document: Document) -> None:
    normal = document.styles["Normal"]
    normal.font.name = "Microsoft YaHei"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)

    for style_name, size in [("Title", 20), ("Heading 1", 16), ("Heading 2", 13), ("Heading 3", 11.5)]:
        style = document.styles[style_name]
        style.font.name = "Microsoft YaHei"
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        style.font.size = Pt(size)
        style.font.bold = True


def build_docx() -> None:
    document = Document()
    format_document_styles(document)
    for section in document.sections:
        set_doc_margins(section)

    title = document.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(TITLE)
    run.bold = True
    run.font.name = "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor(0x12, 0x3D, 0x5A)

    subtitle = document.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run(SUBTITLE)
    run.font.name = "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(11)
    run.font.color.rgb = RGBColor(0x4F, 0x63, 0x73)

    meta = document.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = meta.add_run(f"作者：{AUTHOR}    日期：{DATE_TEXT}")
    run.font.name = "Microsoft YaHei"
    run._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    run.font.size = Pt(10.5)
    run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    document.add_page_break()

    document.add_heading("1. 文档目标与适用范围", level=1)
    add_bullet_list(
        document,
        [
            "目标：给出制品部署后的回退能力建设方案，并兼顾治理可操作性与平台落地性。",
            "范围：镜像类制品、DDL、DML，并预留配置类制品治理位。",
            "适用对象：平台研发、运维、DBA、应用研发负责人以及变更审批人。",
        ],
    )

    document.add_heading("2. 核心结论", level=1)
    add_numbered_list(document, CORE_CONCLUSION)

    document.add_heading("3. 两种建设路径分析", level=1)
    document.add_heading("3.1 不使用元数据", level=2)
    add_bullet_list(document, WITHOUT_METADATA_POINTS)
    document.add_heading("3.2 使用元数据", level=2)
    add_bullet_list(document, WITH_METADATA_POINTS)
    document.add_heading("3.3 对比分析", level=2)
    add_table(document, ["维度", "不使用元数据", "使用元数据"], COMPARISON_ROWS)

    document.add_heading("4. 推荐方案", level=1)
    add_bullet_list(
        document,
        [
            "总体方案：元数据驱动 + 分类型回退策略 + 自动校验与验收 + 审计闭环。",
            "短期起步：以 release-manifest.yaml 作为文件化元数据，嵌入每次发布交付物。",
            "中期形态：汇总到中心元数据仓库，统一状态机、策略执行和审计。",
            "长期目标：形成面向多系统、多环境、多制品类型的统一回退引擎。",
        ],
    )

    document.add_heading("5. 元数据模型设计", level=1)
    add_table(document, ["字段", "说明", "示例"], METADATA_FIELDS)
    document.add_heading("5.1 回退策略枚举", level=2)
    add_table(document, ["策略", "含义"], ROLLBACK_POLICIES)
    document.add_heading("5.2 manifest 示例", level=2)
    for line in MANIFEST_EXAMPLE.splitlines():
        paragraph = document.add_paragraph()
        paragraph.paragraph_format.left_indent = Cm(0.8)
        paragraph.paragraph_format.space_after = Pt(0)
        run = paragraph.add_run(line)
        run.font.name = "Consolas"
        run.font.size = Pt(9.5)

    document.add_heading("6. 发布与回退状态机", level=1)
    add_bullet_list(document, STATE_MACHINE_LINES)
    add_bullet_list(
        document,
        [
            "只有 DIRECT_ROLLBACK 才默认允许自动回退。",
            "COMPENSATE、RESTORE_FROM_BACKUP、MANUAL_ONLY 必须按规则进入不同恢复路径。",
            "任意制品回退失败后，发布单进入 MANUAL_RECOVERY，并触发人工处置流程。",
        ],
    )

    document.add_heading("7. 分类型回退策略", level=1)
    document.add_heading("7.1 镜像类", level=2)
    add_bullet_list(document, IMAGE_STRATEGY)
    document.add_heading("7.2 DDL 类", level=2)
    add_bullet_list(document, DDL_STRATEGY)
    document.add_heading("7.3 DML 类", level=2)
    add_bullet_list(document, DML_STRATEGY)

    document.add_heading("8. 治理要求", level=1)
    add_bullet_list(document, GOVERNANCE_RULES)

    document.add_heading("9. 典型风险与控制点", level=1)
    add_table(document, ["典型风险", "控制建议"], RISKS)

    document.add_heading("10. 落地路线图", level=1)
    for phase, bullets in ROADMAP_PHASES:
        document.add_heading(phase, level=2)
        add_bullet_list(document, bullets)

    document.add_heading("11. MVP 建议", level=1)
    add_numbered_list(document, MVP_ACTIONS)

    document.add_heading("12. 最终建议", level=1)
    add_bullet_list(
        document,
        [
            "最佳方案不是追求“所有制品都可自动反向回退”，而是建立可分类、可约束、可审计的恢复体系。",
            "如果只能先做一件事，应优先统一 manifest、回退策略枚举和发布/回退状态机。",
            "镜像回退要率先实现全自动；DDL 要率先实现兼容性治理；DML 要率先实现补偿和备份门禁。",
        ],
    )

    section = document.add_section(WD_SECTION.NEW_PAGE)
    set_doc_margins(section)
    document.add_heading("附录：汇报摘要", level=1)
    add_bullet_list(
        document,
        [
            "从治理角度，使用元数据明显优于不使用元数据。",
            "镜像、DDL、DML 不应使用同一回退模型。",
            "文件化元数据是最适合落地的过渡形态。",
            "平台化的关键在于状态机、规则引擎、校验器和审计链路。",
        ],
    )

    document.save(DOCX_PATH)


def add_slide_title(slide, title: str, subtitle: str | None = None) -> None:
    title_box = slide.shapes.add_textbox(PPTCm(1.1), PPTCm(0.6), PPTCm(20.5), PPTCm(1.8))
    tf = title_box.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = title
    r.font.name = "Microsoft YaHei"
    r.font.size = PPTPt(24)
    r.font.bold = True
    r.font.color.rgb = PPTColor(0x12, 0x3D, 0x5A)
    if subtitle:
        p2 = tf.add_paragraph()
        p2.text = subtitle
        p2.font.name = "Microsoft YaHei"
        p2.font.size = PPTPt(10)
        p2.font.color.rgb = PPTColor(0x5C, 0x6B, 0x73)

    line = slide.shapes.add_shape(
        MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(1.1), PPTCm(2.2), PPTCm(4.0), PPTCm(0.12)
    )
    line.fill.solid()
    line.fill.fore_color.rgb = PPTColor(0xD9, 0x8E, 0x04)
    line.line.color.rgb = PPTColor(0xD9, 0x8E, 0x04)


def style_slide_background(slide, color: tuple[int, int, int]) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = PPTColor(*color)


def add_bullets_to_slide(slide, bullets: list[str], left: float = 1.25, top: float = 2.8, width: float = 21.0, height: float = 10.5) -> None:
    textbox = slide.shapes.add_textbox(PPTCm(left), PPTCm(top), PPTCm(width), PPTCm(height))
    tf = textbox.text_frame
    tf.word_wrap = True
    tf.margin_left = 0
    tf.margin_right = 0
    tf.margin_top = 0
    tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.TOP
    tf.clear()
    for idx, bullet in enumerate(bullets):
        p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
        p.text = bullet
        p.level = 0
        p.font.name = "Microsoft YaHei"
        p.font.size = PPTPt(18)
        p.font.color.rgb = PPTColor(0x1F, 0x1F, 0x1F)
        p.space_after = PPTPt(10)
        p.line_spacing = 1.2
        p.bullet = True


def add_table_like_boxes(slide, headers: list[str], rows: list[tuple[str, ...]], left: float, top: float, col_widths: list[float]) -> None:
    row_height = 1.1
    x = left
    for idx, header in enumerate(headers):
        box = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(x), PPTCm(top), PPTCm(col_widths[idx]), PPTCm(row_height))
        box.fill.solid()
        box.fill.fore_color.rgb = PPTColor(0xD9, 0xE2, 0xF3)
        box.line.color.rgb = PPTColor(0x8F, 0xA9, 0xC4)
        tf = box.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run()
        run.text = header
        run.font.name = "Microsoft YaHei"
        run.font.size = PPTPt(12)
        run.font.bold = True
        x += col_widths[idx]

    for ridx, row in enumerate(rows):
        x = left
        y = top + row_height + ridx * row_height
        for cidx, value in enumerate(row):
            box = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(x), PPTCm(y), PPTCm(col_widths[cidx]), PPTCm(row_height))
            box.fill.solid()
            box.fill.fore_color.rgb = PPTColor(0xFF, 0xFF, 0xFF)
            box.line.color.rgb = PPTColor(0xCF, 0xD7, 0xDF)
            tf = box.text_frame
            tf.clear()
            p = tf.paragraphs[0]
            p.alignment = PP_ALIGN.LEFT
            run = p.add_run()
            run.text = value
            run.font.name = "Microsoft YaHei"
            run.font.size = PPTPt(11)
            run.font.color.rgb = PPTColor(0x33, 0x33, 0x33)
            x += col_widths[cidx]


def build_pptx() -> None:
    prs = Presentation()
    prs.slide_width = PPTCm(33.867)
    prs.slide_height = PPTCm(19.05)

    cover = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(cover, (248, 246, 240))
    accent = cover.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(0), PPTCm(0), PPTCm(33.867), PPTCm(5.8))
    accent.fill.solid()
    accent.fill.fore_color.rgb = PPTColor(0x12, 0x3D, 0x5A)
    accent.line.color.rgb = PPTColor(0x12, 0x3D, 0x5A)
    accent2 = cover.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(23.2), PPTCm(13.2), PPTCm(10.6), PPTCm(5.85))
    accent2.fill.solid()
    accent2.fill.fore_color.rgb = PPTColor(0xD9, 0x8E, 0x04)
    accent2.line.color.rgb = PPTColor(0xD9, 0x8E, 0x04)
    title_box = cover.shapes.add_textbox(PPTCm(1.3), PPTCm(6.2), PPTCm(23.0), PPTCm(5.0))
    tf = title_box.text_frame
    p = tf.paragraphs[0]
    run = p.add_run()
    run.text = TITLE
    run.font.name = "Microsoft YaHei"
    run.font.size = PPTPt(28)
    run.font.bold = True
    run.font.color.rgb = PPTColor(0x12, 0x3D, 0x5A)
    p2 = tf.add_paragraph()
    p2.text = SUBTITLE
    p2.font.name = "Microsoft YaHei"
    p2.font.size = PPTPt(14)
    p2.font.color.rgb = PPTColor(0x4F, 0x63, 0x73)
    p3 = tf.add_paragraph()
    p3.text = f"{DATE_TEXT}  |  交付物：文档 + 汇报稿"
    p3.font.name = "Microsoft YaHei"
    p3.font.size = PPTPt(11)
    p3.font.color.rgb = PPTColor(0x74, 0x74, 0x74)

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "1. 为什么要重新定义“回退”")
    add_bullets_to_slide(
        slide,
        [
            "部署后的制品不是同质对象，镜像、DDL、DML 的恢复方式天然不同。",
            "如果把回退理解成“统一反向执行”，高概率会在数据库和数据层制造二次事故。",
            "治理目标不只是“能回退”，而是明确什么能回、何时能回、如何回、回完如何验证。",
        ],
    )

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "2. 两种建设路径：不使用元数据 vs 使用元数据")
    add_table_like_boxes(
        slide,
        ["维度", "不使用元数据", "使用元数据"],
        COMPARISON_ROWS,
        left=1.1,
        top=3.0,
        col_widths=[5.0, 8.3, 8.3],
    )

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (250, 250, 250))
    add_slide_title(slide, "3. 核心判断")
    add_bullets_to_slide(slide, CORE_CONCLUSION, top=3.0)

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "4. 最优路线")
    add_bullets_to_slide(
        slide,
        [
            "目标形态：元数据驱动 + 分类型回退策略 + 自动校验验收 + 审计闭环。",
            "短期起步：文件化 manifest，跟随制品交付。",
            "中期建设：中心元数据仓库 + 状态机 + 规则引擎 + 编排执行器。",
            "长期结果：自动回退、人工介入、禁止回退三类策略清晰分流。",
        ],
    )

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "5. 元数据最少要描述什么")
    add_bullets_to_slide(
        slide,
        [
            "制品身份：artifactType、version、sourceRef、owner、env。",
            "依赖关系：deployOrder、dependsOn、compatibility。",
            "回退规则：reversible、rollbackPolicy、rollbackTarget。",
            "执行门禁：preChecks、postChecks、approvalPolicy、backupRequirement、riskLevel。",
        ],
    )

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (252, 248, 243))
    add_slide_title(slide, "6. 发布/回退状态机")
    add_bullets_to_slide(
        slide,
        [
            "发布单主线：CREATED -> APPROVED -> PRECHECKING -> READY -> DEPLOYING -> VERIFYING -> STABLE",
            "失败分支：VERIFY_FAILED -> ROLLBACK_PENDING -> ROLLING_BACK -> ROLLBACK_VERIFYING",
            "回退结果：ROLLED_BACK / ROLLBACK_FAILED / MANUAL_RECOVERY",
            "规则：只有 DIRECT_ROLLBACK 进入自动回退队列，其余按补偿、备份恢复或人工处理分流。",
        ],
    )

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "7. 分类型策略：镜像类")
    add_bullets_to_slide(slide, IMAGE_STRATEGY)

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "8. 分类型策略：DDL 类")
    add_bullets_to_slide(slide, DDL_STRATEGY)

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "9. 分类型策略：DML 类")
    add_bullets_to_slide(slide, DML_STRATEGY)

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (250, 250, 250))
    add_slide_title(slide, "10. 治理要求")
    add_bullets_to_slide(slide, GOVERNANCE_RULES)

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (255, 255, 255))
    add_slide_title(slide, "11. 落地路线图")
    add_bullets_to_slide(
        slide,
        [
            "阶段 1：统一 manifest、镜像版本规则和一键回退能力。",
            "阶段 2：DDL 分类治理，强制兼容性迁移和审批门禁。",
            "阶段 3：DML 补偿、checkpoint、快照与续跑能力。",
            "阶段 4：中心化元数据、统一状态机、审计和告警收口。",
        ],
    )

    slide = prs.slides.add_slide(prs.slide_layouts[6])
    style_slide_background(slide, (248, 246, 240))
    add_slide_title(slide, "12. 建议你优先推进的三件事")
    add_bullets_to_slide(
        slide,
        [
            "先定 release-manifest.yaml 规范，统一回退策略枚举。",
            "再把发布/回退状态机固化到流水线和部署平台。",
            "最后以镜像为起点做自动回退，以 DDL/DML 为重点做治理门禁。",
        ],
        top=3.2,
    )

    prs.save(PPTX_PATH)


def build_text_files() -> None:
    MD_PATH.write_text(MARKDOWN_TEXT, encoding="utf-8")
    NOTE_PATH.write_text(
        "\n".join(
            [
                f"交付目录: {BASE_DIR}",
                f"文档: {DOCX_PATH.name}",
                f"PPT: {PPTX_PATH.name}",
                f"Markdown 源稿: {MD_PATH.name}",
                "",
                "说明:",
                "1. 用户要求写入 F:\\，但当前执行环境对 F:\\ 无写权限，因此产物生成在 C:\\Users\\ljm 下。",
                "2. 内容主题为“制品部署后回退治理方案”，覆盖镜像、DDL、DML 三类制品。",
            ]
        ),
        encoding="utf-8",
    )


def main() -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    build_text_files()
    build_docx()
    build_pptx()


if __name__ == "__main__":
    main()
