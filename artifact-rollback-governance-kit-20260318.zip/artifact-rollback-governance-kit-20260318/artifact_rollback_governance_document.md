# 制品部署后回退治理方案

## 1. 文档说明

- 主题：部署后制品回退能力的建设与治理
- 范围：镜像类、DDL、DML，兼顾配置类制品
- 目标读者：平台研发、运维、DBA、应用研发负责人
- 日期：2026-03-18

## 2. 核心结论

- 回退不应设计成一个统一动作，而应设计成一套分类型恢复机制。
- 镜像类以版本回退为主，DDL 以向前兼容和前滚修复为主，DML 以补偿和备份恢复为主。
- 从治理角度，最优路线是“元数据驱动 + 分类型策略 + 自动校验验收 + 审计闭环”。
- 短期可先用文件化元数据 manifest 起步，中期再沉淀为中心化元数据和统一编排能力。

## 3. 不使用元数据与使用元数据的两种建设路径

### 3.1 不使用元数据

- 以脚本约定、发布单、人工经验和部署平台历史记录支撑回退。
- 镜像依赖 tag 或历史 revision，DDL 依赖 up/down.sql，DML 依赖人工补偿脚本。
- 优点是上手快、改造小、适合低复杂度场景。
- 缺点是回退能力不稳定，强依赖人，无法统一编排，难以自动审计和风险拦截。

### 3.2 使用元数据

- 以制品元数据显式描述制品类型、版本、依赖、回退策略、校验项、审批和备份要求。
- 系统可基于元数据决定某个制品是否可回退、如何回退、何时禁止自动回退。
- 优点是可治理、可审计、可编排、可做统一前后检查。
- 代价是需要建设元数据模型、执行引擎以及研发/DBA/运维的产物规范。

### 3.3 对比结论

| 维度 | 不使用元数据 | 使用元数据 |
| --- | --- | --- |
| 建设成本 | 低，依赖现有流程和脚本 | 中高，需要建模和平台能力 |
| 落地速度 | 快 | 中等 |
| 自动化程度 | 低 | 高 |
| 跨制品统一编排 | 弱 | 强 |
| 审批与审计 | 碎片化 | 可标准化 |
| 高风险变更治理 | 主要靠人 | 可通过规则系统拦截 |
| 长期可扩展性 | 差 | 好 |

## 4. 最优方案

建议方案：**元数据驱动 + 分类型回退策略 + 自动校验与验收 + 审计闭环**。

短期采用文件化元数据 manifest，作为工程落地起点；中期将元数据沉淀到中心仓库；长期形成统一回退引擎。

## 5. 元数据模型

| 字段 | 说明 | 示例 |
| --- | --- | --- |
| releaseId | 发布单唯一标识 | rel-20260318-001 |
| system | 系统或应用名 | order-center |
| env | 目标环境 | prod |
| artifactType | 制品类型 | image / ddl / dml / config |
| version | 版本号 | 2.4.1 / V20260318_01 |
| sourceRef | 来源引用 | 镜像 digest、git commit、SQL 路径 |
| deployOrder | 部署顺序 | 10 / 20 / 30 |
| dependsOn | 依赖制品 | order-api depends on schema |
| reversible | 是否天然可逆 | true / false |
| rollbackPolicy | 回退策略 | DIRECT_ROLLBACK 等 |
| rollbackTarget | 回退目标 | previous_stable |
| preChecks | 执行前校验 | image_exists, backup_exists |
| postChecks | 执行后验证 | health_check, sample_verify |
| approvalPolicy | 审批策略 | AUTO / MANUAL |
| backupRequirement | 备份要求 | NONE / SNAPSHOT_REQUIRED |
| compatibility | 兼容性要求 | minSchemaVersion 等 |
| riskLevel | 风险等级 | low / medium / high |
| owner | 责任团队 | app-team / dba-team / data-team |

### 5.1 回退策略枚举

| 策略 | 含义 |
| --- | --- |
| DIRECT_ROLLBACK | 直接回退到指定或上一稳定版本 |
| COMPENSATE | 通过补偿动作恢复 |
| FORWARD_FIX_ONLY | 不允许反向回退，仅允许前滚修复 |
| RESTORE_FROM_BACKUP | 依赖备份点或快照恢复 |
| MANUAL_ONLY | 系统不自动处理，只允许人工处理 |

### 5.2 manifest 示例

```yaml
releaseId: rel-20260318-001
system: order-center
env: prod
riskLevel: high
rollbackWindow: 30m
overallRollbackPolicy: PARTIAL_AUTO

artifacts:
  - artifactId: order-api
    artifactType: image
    version: 2.4.1
    sourceRef: registry.xxx/order-api@sha256:abc123
    deployOrder: 10
    reversible: true
    rollbackPolicy: DIRECT_ROLLBACK
    rollbackTarget: previous_stable
    compatibility:
      minSchemaVersion: 2026.03.0
      maxSchemaVersion: 2026.03.x

  - artifactId: order-schema-20260318
    artifactType: ddl
    version: V20260318_01
    sourceRef: sql/V20260318_01.sql
    deployOrder: 20
    reversible: false
    rollbackPolicy: FORWARD_FIX_ONLY
    compatibility:
      mode: expand

  - artifactId: order-backfill-20260318
    artifactType: dml
    version: BF20260318_01
    sourceRef: sql/BF20260318_01.sql
    deployOrder: 30
    reversible: false
    rollbackPolicy: COMPENSATE

```

## 6. 发布与回退状态机

- 发布单主状态：CREATED -> APPROVED -> PRECHECKING -> READY -> DEPLOYING -> VERIFYING -> STABLE
- 失败分支：VERIFY_FAILED -> ROLLBACK_PENDING -> ROLLING_BACK -> ROLLBACK_VERIFYING -> ROLLED_BACK / ROLLBACK_FAILED
- 制品状态：PENDING -> PRECHECKING -> READY -> EXECUTING -> EXECUTED -> VERIFYING -> SUCCEEDED
- 治理规则：仅 DIRECT_ROLLBACK 进入自动回退队列；任何回退失败一律进入 MANUAL_RECOVERY。

## 7. 分类型回退策略

### 7.1 镜像类

- 镜像必须以不可变版本标识为准，优先记录 digest，而不是仅使用 tag。
- 部署时记录 current、candidate、previous_stable 三个版本指针。
- 回退前做 schema 兼容性校验，避免应用回退到与现有表结构不兼容的版本。
- 回退动作本质是将 workload 指回上一稳定版本，并在完成后自动做健康检查、核心接口探测和容量观察。

### 7.2 DDL 类

- DDL 不应默认追求 down.sql 式回退，核心是降低必须回退的概率。
- 强制采用 expand -> migrate -> contract 的兼容性迁移模式。
- expand 类 DDL 可随主流程推进；contract 类 DDL 延后执行，并与应用稳定窗口解耦。
- 高风险 DDL 默认不进入自动回退，而是执行前滚修复、快照恢复或人工恢复。

### 7.3 DML 类

- DML 回退原则上走补偿，而不是反向 SQL。
- 执行前应声明影响范围、where 条件摘要、分批策略、可暂停能力和补偿方案。
- 批量 DML 必须具备 checkpoint 机制，并在高风险场景下要求快照或备份点。
- 删除类、覆盖类和业务含义强的数据修复类 DML，默认仅允许补偿或备份恢复。

## 8. 治理要求

- 所有制品随包携带 release-manifest.yaml，作为短期文件化元数据的落地形态。
- 回退前必须经过 pre-check：目标版本可用、依赖满足、无未完成变更、审批已完成、备份存在。
- 回退后必须经过 post-check：应用健康、关键 SQL 校验、关键链路探测、样本一致性抽检。
- 全链路必须落审计：谁在何时对哪个环境执行了什么回退，结果如何，影响了哪些对象。
- 定期演练：至少对镜像一键回退、DDL 前滚修复、DML 补偿恢复做场景化演练。

## 9. 风险与控制点

| 典型风险 | 控制建议 |
| --- | --- |
| 只做镜像回退，不做 schema 兼容 | 应用可能回退成功但功能仍然不可用。 |
| DDL 追求通用自动 down.sql | 极易在复杂数据状态下制造二次事故。 |
| DML 不声明补偿策略 | 出现问题时只能停留在人工修数和低效排障。 |
| 没有统一元数据 | 难以规模化治理不同制品和不同系统。 |

## 10. 落地路线图

### 第一阶段：先把镜像回退做扎实

- 统一镜像不可变版本规则。
- 部署记录保留 previous_stable。
- 支持一键回退和自动健康检查。
### 第二阶段：将 DDL 纳入兼容性治理

- DDL 分为 expand / migrate / contract 三类。
- 高风险 DDL 强制人工审批。
- contract 类变更从主发布流程中延迟执行。
### 第三阶段：把 DML 纳入补偿体系

- 要求补偿脚本和 checkpoint 机制。
- 批量 DML 强制快照或备份点。
- 建立分批、暂停、续跑能力。
### 第四阶段：平台化收口

- 汇总 manifest 到中心元数据仓库。
- 统一状态机、编排、审批、审计和告警。
- 形成“自动回退 / 人工介入 / 禁止回退”三类策略分流。

## 11. MVP 建议

- 确定 release-manifest.yaml 规范和回退策略枚举。
- 把发布/回退状态机固化进流水线和部署平台。
- 先对镜像实现 DIRECT_ROLLBACK。
- 为 DDL 加入分类和审批门禁，为 DML 加入补偿和备份门禁。

## 12. 结论

最佳路线不是追求“所有制品都能自动反向回退”，而是建立“知道哪些能回、哪些不能回、如何回、回完如何验证”的治理体系。对于你负责的部署与治理工作，优先级应放在元数据规范、状态机、镜像回退能力和数据库变更治理规范上。
