from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from pptx import Presentation
from pptx.dml.color import RGBColor as PPTColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Cm as PPTCm
from pptx.util import Pt as PPTPt

BASE = Path(r"C:\Users\ljm\artifact-rollback-governance-architecture-pack-20260318")
DIAGRAMS = BASE / "diagrams"
DOCX = BASE / "artifact_rollback_governance_technical_review.docx"
PPTX = BASE / "artifact_rollback_governance_exec_brief.pptx"
MD = BASE / "artifact_rollback_governance_technical_review.md"
NOTE = BASE / "delivery_note.txt"
FONT = r"C:\Windows\Fonts\msyh.ttc"
FONT_BOLD = r"C:\Windows\Fonts\msyhbd.ttc"

BG = (247, 244, 236)
NAVY = (18, 61, 90)
ORANGE = (217, 142, 4)
TEAL = (56, 122, 127)
LINE = (190, 198, 203)
WHITE = (255, 255, 255)
TEXT = (40, 40, 40)
MUTED = (95, 95, 95)
BLUEBOX = (220, 230, 241)
GREENBOX = (225, 241, 235)
ORANGEBOX = (249, 236, 214)

TITLE = "制品部署后回退治理方案"
DATE = "2026-03-18"

DIAGRAM_PATHS = {
    "overall": DIAGRAMS / "01_overall_governance_architecture.png",
    "state": DIAGRAMS / "02_release_rollback_state_machine.png",
    "strategy": DIAGRAMS / "03_artifact_rollback_strategy_map.png",
    "integration": DIAGRAMS / "04_platform_integration_architecture.png",
}

CORE = [
    "回退不是统一动作，而是分类型恢复机制。",
    "镜像类优先支持自动回退；DDL 以兼容性治理和前滚修复为主；DML 以补偿和备份恢复为主。",
    "长期最优方案是元数据驱动，短期起点是文件化 manifest。",
    "治理重点不是“都能回”，而是“知道哪些能回、怎么回、何时不能回、回后如何验证”。",
]

COMPARE = [
    ("建设成本", "低，依赖人工脚本与流程", "中高，需要元数据和规则引擎"),
    ("自动化", "低", "高"),
    ("跨制品编排", "弱", "强"),
    ("审计能力", "分散", "统一"),
    ("风险拦截", "靠经验", "靠规则"),
    ("长期扩展性", "差", "好"),
]

METADATA = [
    ("releaseId", "发布单唯一 ID", "rel-20260318-001"),
    ("artifactType", "制品类型", "image / ddl / dml / config"),
    ("version", "版本号", "2.4.1 / V20260318_01"),
    ("sourceRef", "来源引用", "digest / commit / sql path"),
    ("deployOrder", "部署顺序", "10 / 20 / 30"),
    ("dependsOn", "依赖关系", "schema before image"),
    ("reversible", "是否天然可逆", "true / false"),
    ("rollbackPolicy", "回退策略", "DIRECT_ROLLBACK 等"),
    ("rollbackTarget", "回退目标", "previous_stable"),
    ("preChecks", "前置检查", "image_exists / backup_exists"),
    ("postChecks", "后置验收", "health_check / sample_verify"),
    ("approvalPolicy", "审批要求", "AUTO / MANUAL"),
    ("backupRequirement", "备份要求", "SNAPSHOT_REQUIRED"),
]

POLICIES = [
    ("DIRECT_ROLLBACK", "直接回退到上一稳定版本"),
    ("COMPENSATE", "以补偿动作恢复"),
    ("FORWARD_FIX_ONLY", "仅允许前滚修复"),
    ("RESTORE_FROM_BACKUP", "依赖快照或备份恢复"),
    ("MANUAL_ONLY", "只允许人工处理"),
]

IMAGE_POINTS = [
    "镜像必须记录不可变版本，优先使用 digest。",
    "部署记录要维护 current、candidate、previous_stable 三个指针。",
    "回退前必须做 schema 兼容性校验。",
    "回退后自动做健康检查、关键接口探测和容量观察。",
]

DDL_POINTS = [
    "DDL 核心不是自动回退，而是 expand -> migrate -> contract 的兼容性治理。",
    "高风险 DDL 默认不进入自动回退，而是走前滚修复或人工恢复。",
    "contract 类收缩变更延后执行，与主发布解耦。",
    "执行前必须校验锁风险、复制延迟和备份点。",
]

DML_POINTS = [
    "DML 默认走补偿，不做通用反向 SQL。",
    "批量 DML 必须支持分批、checkpoint、暂停和续跑。",
    "高风险 DML 必须声明影响范围并准备快照或备份点。",
    "删除类、覆盖类 DML 原则上不进入自动回退。",
]

ROADMAP = [
    ("阶段 1", "统一 manifest、镜像不可变版本和一键回退"),
    ("阶段 2", "DDL 分类治理与审批门禁"),
    ("阶段 3", "DML 补偿、checkpoint、备份恢复"),
    ("阶段 4", "中心化元数据、统一状态机和审计告警"),
]

VALUES = [
    "缩短故障恢复时间，减少回退时的人肉判断。",
    "把高风险数据库变更从经验处理转成规则治理。",
    "形成跨应用、跨环境、跨制品的一致变更治理能力。",
    "让平台具备可审计、可复盘、可演练的回退闭环。",
]

MANIFEST = """releaseId: rel-20260318-001
system: order-center
env: prod
riskLevel: high
overallRollbackPolicy: PARTIAL_AUTO

artifacts:
  - artifactId: order-api
    artifactType: image
    version: 2.4.1
    sourceRef: registry.xxx/order-api@sha256:abc123
    deployOrder: 10
    reversible: true
    rollbackPolicy: DIRECT_ROLLBACK
    rollbackTarget: previous_stable

  - artifactId: order-schema-20260318
    artifactType: ddl
    version: V20260318_01
    sourceRef: sql/V20260318_01.sql
    deployOrder: 20
    reversible: false
    rollbackPolicy: FORWARD_FIX_ONLY

  - artifactId: order-backfill-20260318
    artifactType: dml
    version: BF20260318_01
    sourceRef: sql/BF20260318_01.sql
    deployOrder: 30
    reversible: false
    rollbackPolicy: COMPENSATE
"""


def f(size: int, bold: bool = False):
    return ImageFont.truetype(FONT_BOLD if bold else FONT, size)


def canvas():
    img = Image.new("RGB", (1600, 900), BG)
    draw = ImageDraw.Draw(img)
    draw.rectangle((0, 0, 1600, 110), fill=NAVY)
    return img, draw


def box(draw, xy, fill, outline=LINE, width=3):
    draw.rounded_rectangle(xy, radius=24, fill=fill, outline=outline, width=width)


def text_left(draw, x, y, text, size, fill=TEXT, bold=False, gap=8):
    font_obj = f(size, bold)
    for line in text.split("\n"):
        draw.text((x, y), line, font=font_obj, fill=fill)
        bb = draw.textbbox((x, y), line, font=font_obj)
        y += (bb[3] - bb[1]) + gap


def text_center(draw, xy, text, size, fill=TEXT, bold=False):
    font_obj = f(size, bold)
    lines = text.split("\n")
    x1, y1, x2, y2 = xy
    heights = []
    widths = []
    for line in lines:
        bb = draw.textbbox((0, 0), line, font=font_obj)
        widths.append(bb[2] - bb[0])
        heights.append(bb[3] - bb[1])
    total = sum(heights) + 6 * (len(lines) - 1)
    y = y1 + (y2 - y1 - total) / 2
    for i, line in enumerate(lines):
        x = x1 + (x2 - x1 - widths[i]) / 2
        draw.text((x, y), line, font=font_obj, fill=fill)
        y += heights[i] + 6


def arrow(draw, start, end, fill=NAVY, width=6):
    sx, sy = start
    ex, ey = end
    draw.line((sx, sy, ex, ey), fill=fill, width=width)
    if abs(ex - sx) >= abs(ey - sy):
        sign = 1 if ex >= sx else -1
        p1 = (ex, ey)
        p2 = (ex - 18 * sign, ey - 10)
        p3 = (ex - 18 * sign, ey + 10)
    else:
        sign = 1 if ey >= sy else -1
        p1 = (ex, ey)
        p2 = (ex - 10, ey - 18 * sign)
        p3 = (ex + 10, ey - 18 * sign)
    draw.polygon([p1, p2, p3], fill=fill)


def header(draw, title, sub):
    text_left(draw, 60, 26, title, 34, fill=WHITE, bold=True, gap=4)
    text_left(draw, 62, 70, sub, 16, fill=(220, 230, 235))


def build_overall():
    img, draw = canvas()
    header(draw, "总体治理架构图", "元数据驱动的回退治理闭环")
    boxes = {
        "prod": (70, 180, 330, 330),
        "meta": (420, 180, 720, 330),
        "rule": (820, 180, 1110, 330),
        "orch": (1210, 180, 1510, 330),
        "exec": (220, 470, 700, 710),
        "verify": (820, 470, 1110, 710),
        "audit": (1210, 470, 1510, 710),
    }
    box(draw, boxes["prod"], ORANGEBOX, ORANGE)
    text_center(draw, (70, 190, 330, 255), "制品生产者", 26, bold=True)
    text_center(draw, (70, 228, 330, 285), "研发 / DBA / 运维", 24, bold=True)
    text_left(draw, 100, 286, "镜像\nDDL\nDML\n配置", 18, MUTED, False, 4)
    box(draw, boxes["meta"], BLUEBOX, NAVY)
    text_center(draw, (420, 188, 720, 245), "元数据中心", 28, NAVY, True)
    text_left(draw, 458, 248, "manifest\n版本\n依赖\n回退策略\n审批与备份要求", 18, TEXT, False, 4)
    box(draw, boxes["rule"], GREENBOX, TEAL)
    text_center(draw, (820, 188, 1110, 245), "规则与决策引擎", 28, TEAL, True)
    text_left(draw, 850, 250, "允许自动回退?\n走补偿还是前滚?\n是否需要人工审批?", 18, TEXT, False, 8)
    box(draw, boxes["orch"], ORANGEBOX, ORANGE)
    text_center(draw, (1210, 188, 1510, 245), "发布 / 回退编排器", 28, ORANGE, True)
    text_left(draw, 1254, 250, "状态机\n顺序控制\n超时处理\n失败分流", 18, TEXT, False, 6)
    box(draw, boxes["exec"], WHITE, NAVY)
    text_center(draw, (220, 480, 700, 540), "执行适配层", 28, NAVY, True)
    text_left(draw, 260, 558, "K8s / ECS\n数据库迁移执行器\n备份 / 快照恢复\n补偿脚本执行器", 22)
    box(draw, boxes["verify"], WHITE, TEAL)
    text_center(draw, (820, 480, 1110, 540), "验证中心", 28, TEAL, True)
    text_left(draw, 855, 560, "健康检查\n关键接口探测\nSchema 校验\n数据抽样核对", 22)
    box(draw, boxes["audit"], WHITE, ORANGE)
    text_center(draw, (1210, 480, 1510, 540), "审计与告警", 28, ORANGE, True)
    text_left(draw, 1248, 560, "操作审计\n变更留痕\n风险告警\n演练记录", 22)
    arrow(draw, (330, 255), (420, 255))
    arrow(draw, (720, 255), (820, 255))
    arrow(draw, (1110, 255), (1210, 255))
    arrow(draw, (1360, 330), (1360, 470))
    arrow(draw, (1210, 590), (1110, 590), ORANGE)
    arrow(draw, (820, 590), (700, 590), TEAL)
    arrow(draw, (460, 470), (460, 330))
    text_left(draw, 96, 780, "关键结论：回退能力必须建立在“制品元数据 + 规则决策 + 编排执行 + 校验审计”的闭环上。", 22, NAVY, True)
    img.save(DIAGRAM_PATHS["overall"])


def build_state():
    img, draw = canvas()
    header(draw, "发布 / 回退状态机图", "用状态机显式管理失败后的恢复路径")
    top = [
        ("CREATED", (70, 200, 270, 290)),
        ("APPROVED", (320, 200, 520, 290)),
        ("PRECHECKING", (570, 200, 820, 290)),
        ("DEPLOYING", (870, 200, 1090, 290)),
        ("VERIFYING", (1140, 200, 1350, 290)),
        ("STABLE", (1380, 200, 1530, 290)),
    ]
    for label, area in top:
        box(draw, area, WHITE, NAVY)
        text_center(draw, area, label, 22, NAVY, True)
    for i in range(len(top) - 1):
        arrow(draw, (top[i][1][2], 245), (top[i + 1][1][0], 245))

    fail = [
        ("VERIFY_FAILED", (1140, 390, 1350, 480), ORANGEBOX, ORANGE),
        ("ROLLBACK_PENDING", (1140, 540, 1380, 630), ORANGEBOX, ORANGE),
        ("ROLLING_BACK", (890, 540, 1100, 630), WHITE, TEAL),
        ("ROLLBACK_VERIFYING", (610, 540, 860, 630), WHITE, TEAL),
        ("ROLLED_BACK", (330, 540, 550, 630), WHITE, TEAL),
        ("MANUAL_RECOVERY", (70, 540, 280, 630), WHITE, ORANGE),
    ]
    for label, area, fill, outline in fail:
        box(draw, area, fill, outline)
        text_center(draw, area, label, 20, TEXT, True)
    arrow(draw, (1245, 290), (1245, 390), ORANGE)
    arrow(draw, (1245, 480), (1245, 540), ORANGE)
    arrow(draw, (1140, 585), (1100, 585), ORANGE)
    arrow(draw, (890, 585), (860, 585), TEAL)
    arrow(draw, (610, 585), (550, 585), TEAL)
    arrow(draw, (330, 585), (280, 585), TEAL)
    text_left(draw, 1030, 704, "自动回退条件：\n1. rollbackPolicy = DIRECT_ROLLBACK\n2. 依赖检查通过\n3. 无未完成变更\n4. 验证脚本可执行", 22, TEXT, False, 12)
    text_left(draw, 60, 720, "规则：不是所有失败都自动回退。DDL / DML 更多进入前滚修复、补偿恢复或人工恢复。", 20, NAVY, True)
    img.save(DIAGRAM_PATHS["state"])


def build_strategy():
    img, draw = canvas()
    header(draw, "分类型回退策略图", "镜像、DDL、DML 使用不同恢复模型")
    cols = [
        ("镜像类", (80, 180, 480, 740), BLUEBOX, NAVY, [
            "主策略：DIRECT_ROLLBACK",
            "版本基准：不可变 digest",
            "关键约束：先做 schema 兼容校验",
            "验证方式：实例就绪 + 接口探测",
        ]),
        ("DDL 类", (600, 180, 1000, 740), GREENBOX, TEAL, [
            "主策略：FORWARD_FIX_ONLY",
            "设计方法：expand -> migrate -> contract",
            "关键约束：高风险 DDL 禁止自动回退",
            "验证方式：schema 校验 + 业务验证",
        ]),
        ("DML 类", (1120, 180, 1520, 740), ORANGEBOX, ORANGE, [
            "主策略：COMPENSATE / BACKUP",
            "执行方式：分批 + checkpoint + 可暂停",
            "关键约束：声明补偿方案和备份点",
            "验证方式：行数、样本、业务抽检",
        ]),
    ]
    for title, area, fill, outline, bullets in cols:
        box(draw, area, fill, outline)
        text_center(draw, (area[0], area[1], area[2], area[1] + 80), title, 30, outline, True)
        y = area[1] + 120
        for bullet in bullets:
            text_left(draw, area[0] + 28, y, f"• {bullet}", 21)
            y += 105
    text_left(draw, 110, 790, "结论：镜像追求自动回退；DDL 重在兼容性治理；DML 重在补偿与备份恢复。", 24, NAVY, True)
    img.save(DIAGRAM_PATHS["strategy"])


def build_integration():
    img, draw = canvas()
    header(draw, "平台集成架构图", "把回退治理接入 CI/CD、部署平台、数据库和观测体系")
    left = [
        ("研发 / DBA / 运维", (90, 190, 350, 280), ORANGEBOX, ORANGE),
        ("代码仓库 / SQL 仓库", (90, 340, 350, 430), WHITE, ORANGE),
        ("CI / 构建", (90, 490, 350, 580), WHITE, ORANGE),
        ("制品仓库", (90, 640, 350, 730), WHITE, ORANGE),
    ]
    mid = [
        ("manifest 生成", (520, 240, 800, 330), BLUEBOX, NAVY),
        ("元数据中心", (520, 410, 800, 500), BLUEBOX, NAVY),
        ("发布 / 回退平台", (520, 580, 800, 670), BLUEBOX, NAVY),
    ]
    right = [
        ("K8s / 应用集群", (980, 180, 1280, 280), WHITE, TEAL),
        ("数据库迁移执行器", (980, 340, 1280, 440), WHITE, TEAL),
        ("备份 / 快照系统", (980, 500, 1280, 600), WHITE, TEAL),
        ("监控 / 告警 / 审计", (980, 660, 1280, 760), WHITE, TEAL),
    ]
    for label, area, fill, outline in left + mid + right:
        box(draw, area, fill, outline)
        text_center(draw, area, label, 24, TEXT, True)
    for i in range(len(left) - 1):
        arrow(draw, (220, left[i][1][3]), (220, left[i + 1][1][1]), ORANGE)
    arrow(draw, (350, 535), (520, 285))
    arrow(draw, (350, 685), (520, 455))
    arrow(draw, (660, 330), (660, 410))
    arrow(draw, (660, 500), (660, 580))
    arrow(draw, (800, 625), (980, 230), TEAL)
    arrow(draw, (800, 625), (980, 390), TEAL)
    arrow(draw, (800, 625), (980, 550), TEAL)
    arrow(draw, (1130, 280), (1130, 660), TEAL)
    arrow(draw, (980, 710), (800, 625), ORANGE)
    text_left(draw, 1330, 220, "集成要点：\n1. manifest 随构建产出\n2. 平台统一编排\n3. DB 与应用解耦治理\n4. 监控与审计闭环回流", 22, NAVY, False, 12)
    img.save(DIAGRAM_PATHS["integration"])


def shade(cell, fill: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tc_pr.append(shd)


def doc_style(doc: Document):
    normal = doc.styles["Normal"]
    normal.font.name = "Microsoft YaHei"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    normal.font.size = Pt(11)
    for name, size in [("Title", 20), ("Heading 1", 16), ("Heading 2", 13)]:
        st = doc.styles[name]
        st.font.name = "Microsoft YaHei"
        st._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        st.font.size = Pt(size)
        st.font.bold = True
    for sec in doc.sections:
        sec.top_margin = Cm(2.0)
        sec.bottom_margin = Cm(2.0)
        sec.left_margin = Cm(2.2)
        sec.right_margin = Cm(2.2)


def doc_bullets(doc: Document, items: list[str]):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        r = p.add_run(item)
        r.font.name = "Microsoft YaHei"
        r._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
        r.font.size = Pt(11)


def doc_table(doc: Document, headers: list[str], rows: list[tuple[str, ...]]):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, header_text in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = header_text
        shade(cell, "DCE6F1")
    for row in rows:
        cells = table.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = val
    for row in table.rows:
        for cell in row.cells:
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                for r in p.runs:
                    r.font.name = "Microsoft YaHei"
                    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
                    r.font.size = Pt(10.5)
    doc.add_paragraph()


def doc_image(doc: Document, path: Path, caption: str):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(str(path), width=Cm(15.8))
    c = doc.add_paragraph()
    c.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = c.add_run(caption)
    r.font.name = "Microsoft YaHei"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    r.font.size = Pt(10.5)
    r.font.color.rgb = RGBColor(0x66, 0x66, 0x66)


def build_docx():
    doc = Document()
    doc_style(doc)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(f"{TITLE}\n技术评审版")
    r.font.name = "Microsoft YaHei"
    r._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    r.font.size = Pt(21)
    r.bold = True
    r.font.color.rgb = RGBColor(*NAVY)
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(f"日期：{DATE}")
    r2.font.name = "Microsoft YaHei"
    r2._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft YaHei")
    r2.font.size = Pt(11)
    doc.add_page_break()

    doc.add_heading("1. 核心判断", level=1)
    doc_bullets(doc, CORE)
    doc.add_heading("2. 两种建设路径对比", level=1)
    doc_table(doc, ["维度", "不使用元数据", "使用元数据"], COMPARE)
    doc.add_heading("3. 推荐总体架构", level=1)
    doc_bullets(doc, [
        "短期起步：随制品交付 release-manifest.yaml，用文件化元数据驱动流程判断。",
        "中期形态：汇总 manifest 到中心元数据仓库，形成统一规则决策与编排。",
        "长期目标：发布、回退、验证、审计融为一个闭环平台能力。",
    ])
    doc_image(doc, DIAGRAM_PATHS["overall"], "图 1  总体治理架构图")
    doc.add_heading("4. 元数据模型设计", level=1)
    doc_table(doc, ["字段", "说明", "示例"], METADATA)
    doc.add_heading("4.1 回退策略枚举", level=2)
    doc_table(doc, ["策略", "说明"], POLICIES)
    doc.add_heading("4.2 manifest 示例", level=2)
    for line in MANIFEST.splitlines():
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.8)
        p.paragraph_format.space_after = Pt(0)
        rr = p.add_run(line)
        rr.font.name = "Consolas"
        rr.font.size = Pt(9.5)
    doc.add_heading("5. 发布与回退状态机", level=1)
    doc_bullets(doc, [
        "发布单主线：CREATED -> APPROVED -> PRECHECKING -> DEPLOYING -> VERIFYING -> STABLE。",
        "失败后并不必然自动回退，而是根据 rollbackPolicy 分流到自动回退、补偿、前滚修复或人工恢复。",
        "任何回退都必须经过前置检查和后置验收。",
    ])
    doc_image(doc, DIAGRAM_PATHS["state"], "图 2  发布 / 回退状态机图")
    doc.add_heading("6. 分类型回退策略", level=1)
    doc.add_heading("6.1 镜像类", level=2)
    doc_bullets(doc, IMAGE_POINTS)
    doc.add_heading("6.2 DDL 类", level=2)
    doc_bullets(doc, DDL_POINTS)
    doc.add_heading("6.3 DML 类", level=2)
    doc_bullets(doc, DML_POINTS)
    doc_image(doc, DIAGRAM_PATHS["strategy"], "图 3  分类型回退策略图")
    doc.add_heading("7. 平台集成设计", level=1)
    doc_bullets(doc, [
        "manifest 应由构建环节自动产出，而不是人工补录。",
        "部署平台统一读取元数据、执行状态机、调用执行适配层，并回收监控与审计结果。",
        "数据库迁移、备份恢复、补偿执行器应作为独立适配器接入，而非耦合在应用发布逻辑中。",
    ])
    doc_image(doc, DIAGRAM_PATHS["integration"], "图 4  平台集成架构图")
    doc.add_heading("8. 落地路线与建议", level=1)
    doc_table(doc, ["阶段", "重点"], ROADMAP)
    doc_bullets(doc, [
        "先做 manifest 规范和回退策略枚举，这是后续治理动作的基础。",
        "自动回退优先从镜像切入，数据库相关变更优先做门禁和兼容性设计。",
        "比起盲目追求一键回退，更重要的是先把不能自动回退的场景讲清楚。",
    ])
    doc.save(DOCX)


def bg(slide, color):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = PPTColor(*color)


def slide_title(slide, title, subtitle=""):
    tb = slide.shapes.add_textbox(PPTCm(1.1), PPTCm(0.55), PPTCm(24), PPTCm(2.0))
    tf = tb.text_frame
    tf.clear()
    p = tf.paragraphs[0]
    p.text = title
    p.font.name = "Microsoft YaHei"
    p.font.size = PPTPt(24)
    p.font.bold = True
    p.font.color.rgb = PPTColor(*NAVY)
    if subtitle:
        p2 = tf.add_paragraph()
        p2.text = subtitle
        p2.font.name = "Microsoft YaHei"
        p2.font.size = PPTPt(10)
        p2.font.color.rgb = PPTColor(95, 106, 113)
    line = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(1.1), PPTCm(2.2), PPTCm(3.8), PPTCm(0.14))
    line.fill.solid()
    line.fill.fore_color.rgb = PPTColor(*ORANGE)
    line.line.color.rgb = PPTColor(*ORANGE)


def slide_bullets(slide, items, left=1.3, top=3.0, width=20.8, height=10.8, size=19):
    tb = slide.shapes.add_textbox(PPTCm(left), PPTCm(top), PPTCm(width), PPTCm(height))
    tf = tb.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.vertical_anchor = MSO_ANCHOR.TOP
    for i, item in enumerate(items):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = item
        p.font.name = "Microsoft YaHei"
        p.font.size = PPTPt(size)
        p.font.color.rgb = PPTColor(*TEXT)
        p.bullet = True
        p.space_after = PPTPt(10)


def slide_pic(slide, path: Path, left: float, top: float, width: float):
    slide.shapes.add_picture(str(path), PPTCm(left), PPTCm(top), width=PPTCm(width))


def value_cards(slide):
    positions = [(1.2, 3.0), (12.0, 3.0), (1.2, 9.0), (12.0, 9.0)]
    for i, text in enumerate(VALUES):
        x, y = positions[i]
        shape = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, PPTCm(x), PPTCm(y), PPTCm(9.8), PPTCm(4.4))
        shape.fill.solid()
        shape.fill.fore_color.rgb = PPTColor(*WHITE)
        shape.line.color.rgb = PPTColor(*LINE)
        tf = shape.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        p.text = text
        p.font.name = "Microsoft YaHei"
        p.font.size = PPTPt(18)
        p.font.color.rgb = PPTColor(*TEXT)
        p.alignment = PP_ALIGN.LEFT


def roadmap_cards(slide):
    xs = [1.2, 8.0, 14.8, 21.6]
    fills = [BLUEBOX, GREENBOX, ORANGEBOX, WHITE]
    lines = [NAVY, TEAL, ORANGE, NAVY]
    for i, (phase, detail) in enumerate(ROADMAP):
        shape = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, PPTCm(xs[i]), PPTCm(4.1), PPTCm(5.8), PPTCm(7.4))
        shape.fill.solid()
        shape.fill.fore_color.rgb = PPTColor(*fills[i])
        shape.line.color.rgb = PPTColor(*lines[i])
        tf = shape.text_frame
        tf.clear()
        p = tf.paragraphs[0]
        p.text = phase
        p.font.name = "Microsoft YaHei"
        p.font.size = PPTPt(19)
        p.font.bold = True
        p.font.color.rgb = PPTColor(*lines[i])
        p.alignment = PP_ALIGN.CENTER
        p2 = tf.add_paragraph()
        p2.text = detail
        p2.font.name = "Microsoft YaHei"
        p2.font.size = PPTPt(15)
        p2.font.color.rgb = PPTColor(*TEXT)
    for i in range(3):
        a = slide.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.CHEVRON, PPTCm(xs[i] + 5.95), PPTCm(6.8), PPTCm(0.9), PPTCm(1.3))
        a.fill.solid()
        a.fill.fore_color.rgb = PPTColor(*ORANGE)
        a.line.color.rgb = PPTColor(*ORANGE)


def build_pptx():
    prs = Presentation()
    prs.slide_width = PPTCm(33.867)
    prs.slide_height = PPTCm(19.05)

    cover = prs.slides.add_slide(prs.slide_layouts[6])
    bg(cover, BG)
    head = cover.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(0), PPTCm(0), PPTCm(33.867), PPTCm(5.6))
    head.fill.solid()
    head.fill.fore_color.rgb = PPTColor(*NAVY)
    head.line.color.rgb = PPTColor(*NAVY)
    flag = cover.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, PPTCm(24.0), PPTCm(13.2), PPTCm(9.9), PPTCm(5.85))
    flag.fill.solid()
    flag.fill.fore_color.rgb = PPTColor(*ORANGE)
    flag.line.color.rgb = PPTColor(*ORANGE)
    tb = cover.shapes.add_textbox(PPTCm(1.3), PPTCm(6.0), PPTCm(23.0), PPTCm(6.0))
    tf = tb.text_frame
    p = tf.paragraphs[0]
    p.text = TITLE
    p.font.name = "Microsoft YaHei"
    p.font.size = PPTPt(28)
    p.font.bold = True
    p.font.color.rgb = PPTColor(*NAVY)
    p2 = tf.add_paragraph()
    p2.text = "领导汇报版"
    p2.font.name = "Microsoft YaHei"
    p2.font.size = PPTPt(16)
    p2.font.color.rgb = PPTColor(80, 90, 96)
    p3 = tf.add_paragraph()
    p3.text = f"{DATE}  |  面向部署平台与变更治理建设"
    p3.font.name = "Microsoft YaHei"
    p3.font.size = PPTPt(11)
    p3.font.color.rgb = PPTColor(110, 110, 110)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "1. 问题定义")
    slide_bullets(slide, [
        "镜像、DDL、DML 被当成同一类对象处理，导致回退策略混乱。",
        "大多数平台只支持版本切回，不具备数据库和数据层面的系统化恢复能力。",
        "缺少元数据、规则决策和验证闭环时，回退动作常常退化成高风险人工操作。",
    ])

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "2. 核心结论")
    slide_bullets(slide, CORE)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "3. 目标架构")
    slide_pic(slide, DIAGRAM_PATHS["overall"], 1.2, 3.0, 30.8)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "4. 为什么必须上元数据")
    slide_bullets(slide, [
        "不使用元数据时，回退逻辑存在于人的经验、脚本命名和发布文档里。",
        "使用元数据后，系统才能显式判断制品类型、依赖、回退策略、检查项和审批门禁。",
        "不使用元数据只能做“回退动作”，使用元数据才能做“回退能力”。",
    ])

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, BG); slide_title(slide, "5. 状态机控制恢复路径")
    slide_pic(slide, DIAGRAM_PATHS["state"], 1.2, 3.0, 30.8)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "6. 三类制品三种思路")
    slide_pic(slide, DIAGRAM_PATHS["strategy"], 1.2, 3.0, 30.8)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "7. 平台如何接入现有体系")
    slide_pic(slide, DIAGRAM_PATHS["integration"], 1.2, 3.0, 30.8)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "8. 推荐先做的三件事")
    slide_bullets(slide, [
        "先统一 release-manifest.yaml 和回退策略枚举。",
        "把发布 / 回退状态机固化到流水线与部署平台。",
        "镜像先自动回退，DDL / DML 先做门禁和兼容性治理。",
    ], top=3.3, size=21)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, BG); slide_title(slide, "9. 落地路线图")
    roadmap_cards(slide)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, BG); slide_title(slide, "10. 预期价值")
    value_cards(slide)

    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg(slide, WHITE); slide_title(slide, "11. 最后的判断")
    slide_bullets(slide, [
        "最佳方案不是追求“所有制品都自动反向回退”，而是建立清晰、分层、可治理的恢复体系。",
        "回退能力的基础设施是：元数据、规则引擎、状态机、执行适配层、验证与审计。",
        "如果只能先投一笔建设资源，优先投在 manifest 规范和镜像回退能力，其次投数据库治理。",
    ])
    prs.save(PPTX)


def write_sources():
    markdown = "# 制品部署后回退治理方案 - 技术评审版\n\n## 核心判断\n" + "\n".join(f"- {x}" for x in CORE)
    markdown += "\n\n## 两种建设路径对比\n\n| 维度 | 不使用元数据 | 使用元数据 |\n| --- | --- | --- |\n"
    markdown += "\n".join(f"| {a} | {b} | {c} |" for a, b, c in COMPARE)
    markdown += "\n\n## 元数据模型\n\n| 字段 | 说明 | 示例 |\n| --- | --- | --- |\n"
    markdown += "\n".join(f"| {a} | {b} | {c} |" for a, b, c in METADATA)
    markdown += "\n\n## manifest 示例\n\n```yaml\n" + MANIFEST + "\n```\n"
    MD.write_text(markdown, encoding="utf-8")
    lines = [
        f"交付目录: {BASE}",
        f"技术评审文档: {DOCX.name}",
        f"领导汇报PPT: {PPTX.name}",
        "架构图:",
        *[f"- {p.name}" for p in DIAGRAM_PATHS.values()],
        "",
        "说明:",
        "1. 已按要求新建单独目录，未覆盖上一版材料。",
        "2. 当前执行环境对 F:\\ 无写权限，因此文件生成在 C:\\Users\\ljm 下。",
        "3. 架构图为 PNG，可直接插入文档、PPT 或即时通信工具。",
    ]
    NOTE.write_text("\n".join(lines), encoding="utf-8")


def main():
    BASE.mkdir(parents=True, exist_ok=True)
    DIAGRAMS.mkdir(parents=True, exist_ok=True)
    build_overall()
    build_state()
    build_strategy()
    build_integration()
    write_sources()
    build_docx()
    build_pptx()


if __name__ == "__main__":
    main()
