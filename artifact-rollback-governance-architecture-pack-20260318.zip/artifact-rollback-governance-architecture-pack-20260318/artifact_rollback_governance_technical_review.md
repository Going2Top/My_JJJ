# 制品部署后回退治理方案 - 技术评审版

## 核心判断
- 回退不是统一动作，而是分类型恢复机制。
- 镜像类优先支持自动回退；DDL 以兼容性治理和前滚修复为主；DML 以补偿和备份恢复为主。
- 长期最优方案是元数据驱动，短期起点是文件化 manifest。
- 治理重点不是“都能回”，而是“知道哪些能回、怎么回、何时不能回、回后如何验证”。

## 两种建设路径对比

| 维度 | 不使用元数据 | 使用元数据 |
| --- | --- | --- |
| 建设成本 | 低，依赖人工脚本与流程 | 中高，需要元数据和规则引擎 |
| 自动化 | 低 | 高 |
| 跨制品编排 | 弱 | 强 |
| 审计能力 | 分散 | 统一 |
| 风险拦截 | 靠经验 | 靠规则 |
| 长期扩展性 | 差 | 好 |

## 元数据模型

| 字段 | 说明 | 示例 |
| --- | --- | --- |
| releaseId | 发布单唯一 ID | rel-20260318-001 |
| artifactType | 制品类型 | image / ddl / dml / config |
| version | 版本号 | 2.4.1 / V20260318_01 |
| sourceRef | 来源引用 | digest / commit / sql path |
| deployOrder | 部署顺序 | 10 / 20 / 30 |
| dependsOn | 依赖关系 | schema before image |
| reversible | 是否天然可逆 | true / false |
| rollbackPolicy | 回退策略 | DIRECT_ROLLBACK 等 |
| rollbackTarget | 回退目标 | previous_stable |
| preChecks | 前置检查 | image_exists / backup_exists |
| postChecks | 后置验收 | health_check / sample_verify |
| approvalPolicy | 审批要求 | AUTO / MANUAL |
| backupRequirement | 备份要求 | SNAPSHOT_REQUIRED |

## manifest 示例

```yaml
releaseId: rel-20260318-001
system: order-center
env: prod
riskLevel: high
overallRollbackPolicy: PARTIAL_AUTO

artifacts:
  - artifactId: order-api
    artifactType: image
    version: 2.4.1
    sourceRef: registry.xxx/order-api@sha256:abc123
    deployOrder: 10
    reversible: true
    rollbackPolicy: DIRECT_ROLLBACK
    rollbackTarget: previous_stable

  - artifactId: order-schema-20260318
    artifactType: ddl
    version: V20260318_01
    sourceRef: sql/V20260318_01.sql
    deployOrder: 20
    reversible: false
    rollbackPolicy: FORWARD_FIX_ONLY

  - artifactId: order-backfill-20260318
    artifactType: dml
    version: BF20260318_01
    sourceRef: sql/BF20260318_01.sql
    deployOrder: 30
    reversible: false
    rollbackPolicy: COMPENSATE

```
